 package cart;
   import java.sql.*;

   public class UserDAO 	
   {
      static Connection currentCon = null;
      static ResultSet rs = null;  
	
 public static UserBean login(UserBean bean) {
	
        
         Statement stmt = null;    
	
         String username = bean.getUsername();    
         String password = bean.getPassword();   
	    
         String searchQuery =
               "select * from user where username='"
                        + username
                        + "' AND password='"
                        + password
                        + "'";
	    try 
      {
         
         currentCon = ConnectionManager.getConnection();
         stmt=currentCon.createStatement();
         rs = stmt.executeQuery(searchQuery);	        
         boolean more = rs.next();
	     if (!more) 
         {
	    	 
	   
        bean.setValid(false);
         } 
	     else if (more) 
         {
	    	 bean.setValid(true);
         }
      } 
	    catch (Exception ex) 
      {
         System.out.println("Log In failed: An Exception has occurred! " + ex);
      } 
	    
   

     return bean;
	
      }	
   }